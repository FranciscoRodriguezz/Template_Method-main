package Sin_Aplicar;

public interface BaseDeDatos {
    void conectar();
    void consultar();
    void cerrarConexion();
}
